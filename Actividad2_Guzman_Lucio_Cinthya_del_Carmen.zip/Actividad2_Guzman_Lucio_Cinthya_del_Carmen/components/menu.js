class CustomMenu extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          nav {
            background-color: #444;
            color: white;
            padding: 1rem;
          }
          ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 1rem;
          }
          li {
            cursor: pointer;
          }
        </style>
        <nav>
          <ul>
            <li>Inicio</li>
            <li>Perfil</li>
            <li>Tabla</li>
            <li>Galería</li>
          </ul>
        </nav>
      `;
    }
  }
  
  customElements.define('custom-menu', CustomMenu);
  