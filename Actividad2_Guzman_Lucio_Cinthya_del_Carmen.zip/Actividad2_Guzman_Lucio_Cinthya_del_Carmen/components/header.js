class CustomHeader extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        header {
          background-color: #333;
          color: white;
          text-align: center;
          padding: 1rem;
        }
      </style>
      <header>
        <h1>Mi Aplicación</h1>
      </header>
    `;
  }
}

customElements.define('custom-header', CustomHeader);
