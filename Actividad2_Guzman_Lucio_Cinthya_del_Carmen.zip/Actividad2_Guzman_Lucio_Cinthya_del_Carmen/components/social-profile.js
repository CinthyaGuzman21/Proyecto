class SocialProfile extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          section {
            padding: 1rem;
            background-color: #f4f4f4;
            border: 1px solid #ddd;
          }
        </style>
        <section>
          <h2>Mi Perfil</h2>
          <p>Nombre: [Cinthya Guzman]</p>
          <p>Email: [cdguzman3@espe.edu.ec]</p>
        </section>
      `;
    }
  }
  
  customElements.define('social-profile', SocialProfile);
  