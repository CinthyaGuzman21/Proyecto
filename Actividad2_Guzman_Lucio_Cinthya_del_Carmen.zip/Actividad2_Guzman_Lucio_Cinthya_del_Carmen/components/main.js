class CustomMain extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          main {
            padding: 1rem;
          }
        </style>
        <main>
          <slot></slot>
        </main>
      `;
    }
  }
  
  customElements.define('custom-main', CustomMain);
  