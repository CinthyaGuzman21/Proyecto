class CustomGallery extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
      this.render();
    }
  
    async render() {
      const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=6');
      const data = await response.json();
      const pokemons = data.results;
  
      this.shadowRoot.innerHTML = `
        <style>
          .gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
          }
          .gallery img {
            width: 100px;
            height: 100px;
          }
        </style>
        <div class="gallery">
          ${pokemons.map(pokemon => `
            <div>
              <p>${pokemon.name}</p>
              <img src="https://img.pokemondb.net/sprites/home/normal/${pokemon.name}.png" alt="${pokemon.name}">
            </div>
          `).join('')}
        </div>
      `;
    }
  }
  
  customElements.define('custom-gallery', CustomGallery);
  