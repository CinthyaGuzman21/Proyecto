class CustomTable extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
      this.render();
    }
  
    async render() {
      const response = await fetch('https://jsonplaceholder.typicode.com/users');
      const users = await response.json();
      this.shadowRoot.innerHTML = `
        <style>
          table {
            width: 100%;
            border-collapse: collapse;
          }
          th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
          }
        </style>
        <table>
          <tr>
            <th>Nombre</th>
            <th>Email</th>
            <th>Teléfono</th>
          </tr>
          ${users.map(user => `
            <tr>
              <td>${user.name}</td>
              <td>${user.email}</td>
              <td>${user.phone}</td>
            </tr>
          `).join('')}
        </table>
      `;
    }
  }
  
  customElements.define('custom-table', CustomTable);
  