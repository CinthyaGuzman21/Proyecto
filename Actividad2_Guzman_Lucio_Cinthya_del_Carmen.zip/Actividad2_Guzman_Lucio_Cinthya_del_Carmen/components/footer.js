class CustomFooter extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          footer {
            background-color: #222;
            color: white;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
          }
        </style>
        <footer>
          <p>© 2024 Mi Aplicación. Todos los derechos reservados.</p>
        </footer>
      `;
    }
  }
  
  customElements.define('custom-footer', CustomFooter);
  